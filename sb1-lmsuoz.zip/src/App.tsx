import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Actions } from './components/Actions';
import { Join } from './components/Join';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      <Hero />
      <Actions />
      <Join />
    </div>
  );
}

export default App;