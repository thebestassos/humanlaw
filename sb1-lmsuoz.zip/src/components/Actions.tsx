import { Users, ShoppingBag, BookOpen, Calendar } from 'lucide-react';

interface ActionCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  image: string;
}

function ActionCard({ title, description, icon, image }: ActionCardProps) {
  return (
    <div className="group relative overflow-hidden rounded-xl bg-black/50 backdrop-blur-sm border border-gold/10 hover:border-gold/30 transition-all">
      <div className="absolute inset-0">
        <img
          src={image}
          alt={title}
          className="h-full w-full object-cover opacity-20 group-hover:opacity-30 transition-opacity"
        />
      </div>
      <div className="relative p-8">
        <div className="mb-4 inline-block rounded-lg bg-gold/10 p-3">
          {icon}
        </div>
        <h3 className="mb-2 text-xl font-bold text-gold">{title}</h3>
        <p className="text-gray-300">{description}</p>
      </div>
    </div>
  );
}

export function Actions() {
  const actions = [
    {
      title: "Distribution Alimentaire",
      description: "Organisation régulière de distributions alimentaires pour les personnes dans le besoin.",
      icon: <ShoppingBag className="h-6 w-6 text-gold" />,
      image: "https://images.unsplash.com/photo-1593113630400-ea4288922497?auto=format&fit=crop&q=80"
    },
    {
      title: "Groupes d'Étude",
      description: "Sessions d'accompagnement et de soutien éducatif pour favoriser le développement personnel.",
      icon: <BookOpen className="h-6 w-6 text-gold" />,
      image: "https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80"
    },
    {
      title: "Événements Sociaux",
      description: "Organisation d'événements communautaires pour renforcer les liens sociaux.",
      icon: <Calendar className="h-6 w-6 text-gold" />,
      image: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&q=80"
    },
    {
      title: "Accompagnement",
      description: "Soutien personnalisé et orientation vers les services sociaux appropriés.",
      icon: <Users className="h-6 w-6 text-gold" />,
      image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&q=80"
    }
  ];

  return (
    <section id="actions" className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gold mb-4">Nos Actions</h2>
          <p className="text-gray-300 max-w-2xl mx-auto">
            Découvrez comment Human Law s'engage concrètement pour créer un impact positif dans la société.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {actions.map((action) => (
            <ActionCard key={action.title} {...action} />
          ))}
        </div>
      </div>
    </section>
  );
}