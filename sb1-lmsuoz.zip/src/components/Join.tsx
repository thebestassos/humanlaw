import { Calendar, Send, Users } from 'lucide-react';

export function Join() {
  return (
    <section id="join" className="py-24 bg-black/95">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl sm:text-4xl font-bold text-gold mb-6">
              Rejoignez Notre Mission
            </h2>
            <p className="text-gray-300 mb-8">
              En devenant membre de Human Law, vous participez activement à la construction d'un monde plus solidaire. Votre engagement fait la différence.
            </p>
            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-gold/10 p-2">
                  <Calendar className="h-5 w-5 text-gold" />
                </div>
                <div>
                  <h3 className="font-semibold text-gold">Flexibilité</h3>
                  <p className="text-gray-300">Participez selon vos disponibilités</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="rounded-full bg-gold/10 p-2">
                  <Users className="h-5 w-5 text-gold" />
                </div>
                <div>
                  <h3 className="font-semibold text-gold">Communauté</h3>
                  <p className="text-gray-300">Rejoignez une équipe engagée</p>
                </div>
              </div>
            </div>
            <a
              href="https://calendly.com/human-law"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-black bg-gold hover:bg-gold/90 transition-colors"
            >
              Prendre Rendez-vous
              <Calendar className="ml-2 h-5 w-5" />
            </a>
          </div>

          <div className="bg-black/50 backdrop-blur-sm rounded-xl p-8 border border-gold/10">
            <h3 className="text-xl font-bold text-gold mb-6">Formulaire d'Adhésion</h3>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-300">
                  Nom complet
                </label>
                <input
                  type="text"
                  id="name"
                  className="mt-1 block w-full rounded-md bg-black/50 border border-gold/20 text-gray-300 px-4 py-2 focus:border-gold focus:ring-gold"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  className="mt-1 block w-full rounded-md bg-black/50 border border-gold/20 text-gray-300 px-4 py-2 focus:border-gold focus:ring-gold"
                />
              </div>
              <div>
                <label htmlFor="interests" className="block text-sm font-medium text-gray-300">
                  Centres d'intérêt
                </label>
                <select
                  id="interests"
                  className="mt-1 block w-full rounded-md bg-black/50 border border-gold/20 text-gray-300 px-4 py-2 focus:border-gold focus:ring-gold"
                >
                  <option value="distribution">Distribution Alimentaire</option>
                  <option value="education">Groupes d'Étude</option>
                  <option value="events">Événements</option>
                  <option value="support">Accompagnement</option>
                </select>
              </div>
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-300">
                  Message
                </label>
                <textarea
                  id="message"
                  rows={4}
                  className="mt-1 block w-full rounded-md bg-black/50 border border-gold/20 text-gray-300 px-4 py-2 focus:border-gold focus:ring-gold"
                ></textarea>
              </div>
              <button
                type="submit"
                className="w-full inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-black bg-gold hover:bg-gold/90 transition-colors"
              >
                Envoyer
                <Send className="ml-2 h-5 w-5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}