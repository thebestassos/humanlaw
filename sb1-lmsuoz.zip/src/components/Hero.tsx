import { ArrowRight } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1593113598332-cd288d649433?auto=format&fit=crop&q=80)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-black/70"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl sm:text-6xl font-bold text-gold mb-6">
          Ensemble, Construisons un Monde Meilleur
        </h1>
        <p className="text-xl sm:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
          Human Law s'engage à créer un impact positif à travers des actions concrètes,
          de la solidarité et du partage.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a 
            href="#join"
            className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-black bg-gold hover:bg-gold/90 transition-colors"
          >
            Nous Rejoindre
            <ArrowRight className="ml-2 h-5 w-5" />
          </a>
          <a 
            href="#actions"
            className="inline-flex items-center justify-center px-6 py-3 border border-gold text-base font-medium rounded-md text-gold hover:bg-gold/10 transition-colors"
          >
            Découvrir Nos Actions
          </a>
        </div>
      </div>
    </div>
  );
}