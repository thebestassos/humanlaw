import { Menu, X, UserCircle } from 'lucide-react';
import { useState } from 'react';
import { Link } from './Link';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { name: 'Nos Actions', href: '#actions' },
    { name: 'Nous Rejoindre', href: '#join' },
    { name: 'Partenaires', href: '#partners' },
    { name: 'Projets', href: '#projects' },
    { name: 'À Propos', href: '#about' },
    { name: 'Participer', href: '#participate' },
  ];

  return (
    <nav className="bg-black/95 fixed w-full z-50 border-b border-gold/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="text-gold font-bold text-xl">HUMAN LAW</Link>
          </div>
          
          <div className="hidden md:block">
            <div className="ml-10 flex items-center space-x-4">
              {navItems.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="text-gray-300 hover:text-gold px-3 py-2 rounded-md text-sm font-medium transition-colors"
                >
                  {item.name}
                </Link>
              ))}
              <Link
                href="/member"
                className="bg-gold text-black px-4 py-2 rounded-md text-sm font-medium hover:bg-gold/90 transition-colors flex items-center gap-2"
              >
                <UserCircle className="w-4 h-4" />
                Espace Membre
              </Link>
            </div>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-300 hover:text-gold p-2"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-black/95">
            {navItems.map((item) => (
              <Link
                key={item.name}
                href={item.href}
                className="text-gray-300 hover:text-gold block px-3 py-2 rounded-md text-base font-medium"
              >
                {item.name}
              </Link>
            ))}
            <Link
              href="/member"
              className="bg-gold text-black block px-3 py-2 rounded-md text-base font-medium hover:bg-gold/90 transition-colors"
            >
              Espace Membre
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}