import { 
  CalendarDays, 
  FileText, 
  MessageSquare, 
  BarChart3,
  Settings,
  Building2,
  LogOut
} from 'lucide-react';

interface SidebarProps {
  currentSection: string;
  setCurrentSection: (section: string) => void;
  currentBranch: string;
  setBranch: (branch: string) => void;
}

export function Sidebar({ 
  currentSection, 
  setCurrentSection, 
  currentBranch, 
  setBranch 
}: SidebarProps) {
  const branches = [
    { id: 'troyes', name: 'Troyes' },
    { id: 'paris', name: 'Paris' },
    { id: 'reims', name: 'Reims' }
  ];

  const navigation = [
    { id: 'calendar', name: 'Calendrier', icon: CalendarDays },
    { id: 'documents', name: 'Documents', icon: FileText },
    { id: 'team-chat', name: 'Discussion', icon: MessageSquare },
    { id: 'statistics', name: 'Statistiques', icon: BarChart3 },
    { id: 'settings', name: 'Paramètres', icon: Settings }
  ];

  return (
    <div className="w-64 bg-black border-r border-gold/20">
      <div className="h-full flex flex-col">
        <div className="flex-1 flex flex-col pt-5 pb-4">
          <div className="flex items-center flex-shrink-0 px-4">
            <span className="text-gold text-xl font-bold">HUMAN LAW</span>
          </div>

          <div className="px-4 mt-6">
            <label className="block text-sm font-medium text-gray-400 mb-2">
              Antenne
            </label>
            <select
              value={currentBranch}
              onChange={(e) => setBranch(e.target.value)}
              className="w-full bg-black/50 border border-gold/20 rounded-md text-gray-300 py-2 px-3"
            >
              {branches.map((branch) => (
                <option key={branch.id} value={branch.id}>
                  {branch.name}
                </option>
              ))}
            </select>
          </div>

          <nav className="mt-8 flex-1 px-2 space-y-1">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentSection(item.id)}
                  className={`w-full flex items-center px-4 py-2 text-sm font-medium rounded-md ${
                    currentSection === item.id
                      ? 'bg-gold/10 text-gold'
                      : 'text-gray-300 hover:bg-gold/5 hover:text-gold'
                  }`}
                >
                  <Icon className="mr-3 h-5 w-5" />
                  {item.name}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="flex-shrink-0 flex border-t border-gold/20 p-4">
          <button
            onClick={() => {/* Handle logout */}}
            className="w-full flex items-center px-4 py-2 text-sm font-medium text-gray-300 hover:bg-gold/5 hover:text-gold rounded-md"
          >
            <LogOut className="mr-3 h-5 w-5" />
            Déconnexion
          </button>
        </div>
      </div>
    </div>
  );
}