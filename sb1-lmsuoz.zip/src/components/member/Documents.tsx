import { File, Upload, Folder } from 'lucide-react';

export function Documents({ branch }: { branch: string }) {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gold">Documents Administratifs</h2>
        <p className="text-gray-300">Antenne de {branch}</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-black/50 rounded-xl p-6 border border-gold/10">
          <h3 className="text-xl font-bold text-gold mb-4">Documents Importants</h3>
          <div className="space-y-4">
            <div className="p-4 bg-black/30 rounded-lg border border-gold/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <File className="h-5 w-5 text-gold" />
                <span className="text-gray-300">Statuts de l'association</span>
              </div>
              <button className="text-gold hover:text-gold/80">
                Télécharger
              </button>
            </div>
            <div className="p-4 bg-black/30 rounded-lg border border-gold/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <File className="h-5 w-5 text-gold" />
                <span className="text-gray-300">Règlement intérieur</span>
              </div>
              <button className="text-gold hover:text-gold/80">
                Télécharger
              </button>
            </div>
          </div>
        </div>

        <div className="bg-black/50 rounded-xl p-6 border border-gold/10">
          <h3 className="text-xl font-bold text-gold mb-4">Ajouter un document</h3>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gold/20 rounded-lg p-8 text-center">
              <Upload className="h-8 w-8 text-gold mx-auto mb-4" />
              <p className="text-gray-300 mb-2">
                Glissez-déposez vos fichiers ici ou
              </p>
              <button className="text-gold hover:text-gold/80 font-medium">
                Parcourir
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}