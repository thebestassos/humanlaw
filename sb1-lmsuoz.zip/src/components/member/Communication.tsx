import { Image, Upload, Send, Paperclip } from 'lucide-react';
import { useState } from 'react';

interface MediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  title: string;
  date: string;
}

export function Communication({ branch }: { branch: string }) {
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([]);
  const [selectedFolder, setSelectedFolder] = useState('photos');

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gold">Communication</h2>
        <p className="text-gray-300">Antenne de {branch}</p>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {/* Media Library */}
        <div className="md:col-span-2 bg-black/50 rounded-xl p-6 border border-gold/10">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold text-gold">Médiathèque</h3>
            <div className="flex gap-2">
              <button
                onClick={() => setSelectedFolder('photos')}
                className={`px-4 py-2 rounded-md text-sm ${
                  selectedFolder === 'photos'
                    ? 'bg-gold text-black'
                    : 'bg-gold/10 text-gold'
                }`}
              >
                Photos
              </button>
              <button
                onClick={() => setSelectedFolder('videos')}
                className={`px-4 py-2 rounded-md text-sm ${
                  selectedFolder === 'videos'
                    ? 'bg-gold text-black'
                    : 'bg-gold/10 text-gold'
                }`}
              >
                Vidéos
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {mediaItems.map((item) => (
              <div
                key={item.id}
                className="relative group aspect-square rounded-lg overflow-hidden border border-gold/10"
              >
                {item.type === 'image' ? (
                  <img
                    src={item.url}
                    alt={item.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <video
                    src={item.url}
                    className="w-full h-full object-cover"
                  />
                )}
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <div className="text-center">
                    <p className="text-gold font-medium">{item.title}</p>
                    <p className="text-sm text-gray-300">{item.date}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Upload Section */}
          <div className="mt-6 border-2 border-dashed border-gold/20 rounded-lg p-8 text-center">
            <Upload className="h-8 w-8 text-gold mx-auto mb-4" />
            <p className="text-gray-300 mb-2">
              Glissez-déposez vos fichiers ici ou
            </p>
            <button className="text-gold hover:text-gold/80 font-medium">
              Parcourir
            </button>
          </div>
        </div>

        {/* Quick Share */}
        <div className="bg-black/50 rounded-xl p-6 border border-gold/10">
          <h3 className="text-xl font-bold text-gold mb-6">Partage Rapide</h3>
          <div className="space-y-4">
            <textarea
              placeholder="Votre message..."
              className="w-full h-32 bg-black/30 border border-gold/20 rounded-lg p-3 text-gray-300 resize-none focus:border-gold focus:ring-gold"
            />
            <div className="flex items-center gap-2">
              <button className="p-2 rounded-md bg-gold/10 text-gold hover:bg-gold/20">
                <Image className="h-5 w-5" />
              </button>
              <button className="p-2 rounded-md bg-gold/10 text-gold hover:bg-gold/20">
                <Paperclip className="h-5 w-5" />
              </button>
              <button className="flex-1 flex items-center justify-center gap-2 bg-gold text-black px-4 py-2 rounded-md hover:bg-gold/90">
                <Send className="h-5 w-5" />
                Partager
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}