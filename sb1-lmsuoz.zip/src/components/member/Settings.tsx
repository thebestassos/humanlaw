import { Bell, Lock, User, Shield } from 'lucide-react';

export function Settings({ branch }: { branch: string }) {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gold">Paramètres</h2>
        <p className="text-gray-300">Antenne de {branch}</p>
      </div>

      <div className="max-w-2xl">
        {/* Profil */}
        <div className="mb-8 bg-black/50 rounded-xl p-6 border border-gold/10">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center">
              <User className="h-8 w-8 text-gold" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-gold">John Doe</h3>
              <p className="text-gray-400">Membre depuis Janvier 2024</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Nom complet
              </label>
              <input
                type="text"
                className="w-full bg-black/30 border border-gold/20 rounded-lg px-4 py-2 text-gray-300 focus:border-gold focus:ring-gold"
                defaultValue="John Doe"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Email
              </label>
              <input
                type="email"
                className="w-full bg-black/30 border border-gold/20 rounded-lg px-4 py-2 text-gray-300 focus:border-gold focus:ring-gold"
                defaultValue="john@example.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Téléphone
              </label>
              <input
                type="tel"
                className="w-full bg-black/30 border border-gold/20 rounded-lg px-4 py-2 text-gray-300 focus:border-gold focus:ring-gold"
                defaultValue="+33 6 12 34 56 78"
              />
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="mb-8 bg-black/50 rounded-xl p-6 border border-gold/10">
          <div className="flex items-center gap-3 mb-6">
            <Bell className="h-6 w-6 text-gold" />
            <h3 className="text-xl font-bold text-gold">Notifications</h3>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-300">Notifications email</p>
                <p className="text-sm text-gray-400">
                  Recevoir des emails pour les nouvelles actions
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-black/30 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-black after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-gold after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gold/20"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-300">Rappels</p>
                <p className="text-sm text-gray-400">
                  Recevoir des rappels avant les actions
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" defaultChecked />
                <div className="w-11 h-6 bg-black/30 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-black after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-gold after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-gold/20"></div>
              </label>
            </div>
          </div>
        </div>

        {/* Sécurité */}
        <div className="bg-black/50 rounded-xl p-6 border border-gold/10">
          <div className="flex items-center gap-3 mb-6">
            <Shield className="h-6 w-6 text-gold" />
            <h3 className="text-xl font-bold text-gold">Sécurité</h3>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Ancien mot de passe
              </label>
              <input
                type="password"
                className="w-full bg-black/30 border border-gold/20 rounded-lg px-4 py-2 text-gray-300 focus:border-gold focus:ring-gold"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Nouveau mot de passe
              </label>
              <input
                type="password"
                className="w-full bg-black/30 border border-gold/20 rounded-lg px-4 py-2 text-gray-300 focus:border-gold focus:ring-gold"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">
                Confirmer le mot de passe
              </label>
              <input
                type="password"
                className="w-full bg-black/30 border border-gold/20 rounded-lg px-4 py-2 text-gray-300 focus:border-gold focus:ring-gold"
              />
            </div>
            <button className="w-full bg-gold text-black px-4 py-2 rounded-md hover:bg-gold/90 transition-colors flex items-center justify-center gap-2">
              <Lock className="h-5 w-5" />
              Mettre à jour le mot de passe
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}