import { BarChart3, TrendingUp, Users, Calendar } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  change?: string;
  icon: React.ReactNode;
}

function StatCard({ title, value, change, icon }: StatCardProps) {
  return (
    <div className="bg-black/30 rounded-lg p-6 border border-gold/10">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gold mt-1">{value}</p>
          {change && (
            <p className="text-sm text-emerald-500 flex items-center gap-1 mt-1">
              <TrendingUp className="h-4 w-4" />
              {change}
            </p>
          )}
        </div>
        <div className="p-2 bg-gold/10 rounded-lg">
          {icon}
        </div>
      </div>
    </div>
  );
}

export function Statistics({ branch }: { branch: string }) {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gold">Statistiques</h2>
        <p className="text-gray-300">Antenne de {branch}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
        <StatCard
          title="Participations ce mois"
          value="42"
          change="+12% vs mois dernier"
          icon={<Calendar className="h-6 w-6 text-gold" />}
        />
        <StatCard
          title="Bénéficiaires aidés"
          value="156"
          change="+8% vs mois dernier"
          icon={<Users className="h-6 w-6 text-gold" />}
        />
        <StatCard
          title="Taux de participation"
          value="87%"
          change="+5% vs mois dernier"
          icon={<BarChart3 className="h-6 w-6 text-gold" />}
        />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Classement des Membres */}
        <div className="bg-black/50 rounded-xl p-6 border border-gold/10">
          <h3 className="text-xl font-bold text-gold mb-6">Top Contributeurs</h3>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((rank) => (
              <div
                key={rank}
                className="flex items-center justify-between p-4 bg-black/30 rounded-lg border border-gold/10"
              >
                <div className="flex items-center gap-4">
                  <span className="text-2xl font-bold text-gold">#{rank}</span>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center">
                      <span className="text-gold font-medium">JD</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-300">John Doe</p>
                      <p className="text-sm text-gray-400">12 participations</p>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-gold font-medium">95%</p>
                  <p className="text-sm text-gray-400">Taux de présence</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Graphique d'Activité */}
        <div className="bg-black/50 rounded-xl p-6 border border-gold/10">
          <h3 className="text-xl font-bold text-gold mb-6">Activité Mensuelle</h3>
          <div className="h-64 flex items-end justify-between gap-2">
            {[...Array(12)].map((_, i) => {
              const height = Math.random() * 100;
              return (
                <div
                  key={i}
                  className="w-full bg-gold/20 rounded-t-sm hover:bg-gold/30 transition-colors relative group"
                  style={{ height: `${height}%` }}
                >
                  <div className="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 bg-black/90 text-gold px-2 py-1 rounded text-sm opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                    {height.toFixed(0)} actions
                  </div>
                </div>
              );
            })}
          </div>
          <div className="flex justify-between mt-4 text-sm text-gray-400">
            <span>Jan</span>
            <span>Déc</span>
          </div>
        </div>
      </div>
    </div>
  );
}