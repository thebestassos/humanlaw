import { useState } from 'react';
import { Sidebar } from './Sidebar';
import { Calendar } from './Calendar';
import { Documents } from './Documents';
import { Communication } from './Communication';
import { TeamChat } from './TeamChat';
import { Statistics } from './Statistics';
import { Settings } from './Settings';

export function Dashboard() {
  const [currentSection, setCurrentSection] = useState('calendar');
  const [currentBranch, setBranch] = useState('troyes');

  const renderContent = () => {
    switch (currentSection) {
      case 'calendar':
        return <Calendar branch={currentBranch} />;
      case 'documents':
        return <Documents branch={currentBranch} />;
      case 'communication':
        return <Communication branch={currentBranch} />;
      case 'team-chat':
        return <TeamChat branch={currentBranch} />;
      case 'statistics':
        return <Statistics branch={currentBranch} />;
      case 'settings':
        return <Settings branch={currentBranch} />;
      default:
        return <Calendar branch={currentBranch} />;
    }
  };

  return (
    <div className="flex h-screen bg-black">
      <Sidebar 
        currentSection={currentSection}
        setCurrentSection={setCurrentSection}
        currentBranch={currentBranch}
        setBranch={setBranch}
      />
      <main className="flex-1 overflow-y-auto bg-black/95">
        {renderContent()}
      </main>
    </div>
  );
}