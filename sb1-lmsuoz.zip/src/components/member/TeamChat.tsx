import { useState } from 'react';
import { Send, Users, Hash } from 'lucide-react';

interface Message {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: string;
  avatar?: string;
}

interface Channel {
  id: string;
  name: string;
  type: 'pole' | 'general';
  unread?: number;
}

export function TeamChat({ branch }: { branch: string }) {
  const [currentChannel, setCurrentChannel] = useState('general');
  const [messages, setMessages] = useState<Message[]>([]);

  const channels: Channel[] = [
    { id: 'general', name: 'Général', type: 'general' },
    { id: 'communication', name: 'Communication', type: 'pole', unread: 3 },
    { id: 'organisation', name: 'Organisation', type: 'pole' },
    { id: 'relationnel', name: 'Relationnel', type: 'pole' },
    { id: 'administratif', name: 'Administratif', type: 'pole' },
    { id: 'commercial', name: 'Commercial', type: 'pole' },
  ];

  return (
    <div className="h-full flex">
      {/* Channels Sidebar */}
      <div className="w-64 bg-black/50 border-r border-gold/20 p-4">
        <div className="mb-6">
          <h3 className="text-gold font-bold mb-2 px-2">Antenne {branch}</h3>
          <div className="flex items-center gap-2 px-2 py-1 rounded-md bg-gold/10">
            <Users className="h-4 w-4 text-gold" />
            <span className="text-sm text-gray-300">23 membres en ligne</span>
          </div>
        </div>

        <div className="space-y-1">
          {channels.map((channel) => (
            <button
              key={channel.id}
              onClick={() => setCurrentChannel(channel.id)}
              className={`w-full flex items-center justify-between px-2 py-2 rounded-md ${
                currentChannel === channel.id
                  ? 'bg-gold/10 text-gold'
                  : 'text-gray-300 hover:bg-gold/5 hover:text-gold'
              }`}
            >
              <div className="flex items-center gap-2">
                <Hash className="h-4 w-4" />
                <span>{channel.name}</span>
              </div>
              {channel.unread && (
                <span className="bg-gold text-black text-xs px-2 py-1 rounded-full">
                  {channel.unread}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 flex flex-col">
        {/* Chat Header */}
        <div className="h-16 border-b border-gold/20 px-6 flex items-center">
          <div>
            <h3 className="text-gold font-bold">
              #{channels.find((c) => c.id === currentChannel)?.name}
            </h3>
            <p className="text-sm text-gray-400">
              Canal de discussion de l'équipe
            </p>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {messages.map((message) => (
            <div key={message.id} className="flex items-start gap-4">
              <div className="w-8 h-8 rounded-full bg-gold/10 flex items-center justify-center">
                {message.avatar ? (
                  <img
                    src={message.avatar}
                    alt={message.userName}
                    className="w-8 h-8 rounded-full"
                  />
                ) : (
                  <span className="text-gold">
                    {message.userName.charAt(0).toUpperCase()}
                  </span>
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-medium text-gold">
                    {message.userName}
                  </span>
                  <span className="text-xs text-gray-400">
                    {message.timestamp}
                  </span>
                </div>
                <p className="text-gray-300">{message.content}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Message Input */}
        <div className="h-24 border-t border-gold/20 p-4">
          <div className="flex items-center gap-2">
            <input
              type="text"
              placeholder="Votre message..."
              className="flex-1 bg-black/30 border border-gold/20 rounded-lg px-4 py-2 text-gray-300 focus:border-gold focus:ring-gold"
            />
            <button className="p-2 rounded-md bg-gold text-black hover:bg-gold/90">
              <Send className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
