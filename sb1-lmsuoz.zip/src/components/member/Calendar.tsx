import { useState } from 'react';
import { Calendar as CalendarIcon, Users, Car, Check, Clock } from 'lucide-react';

interface Event {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  type: 'distribution' | 'study' | 'meeting';
  requiredRoles: {
    responsible: number;
    driver: number;
    volunteer: number;
  };
  participants: {
    userId: string;
    role: 'responsible' | 'driver' | 'volunteer';
    status: 'pending' | 'approved';
  }[];
}

export function Calendar({ branch }: { branch: string }) {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [events, setEvents] = useState<Event[]>([]);

  const handleParticipate = (eventId: string, role: string) => {
    // Handle participation logic
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gold">Calendrier des Actions</h2>
        <p className="text-gray-300">Antenne de {branch}</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-black/50 rounded-xl p-6 border border-gold/10">
          <h3 className="text-xl font-bold text-gold mb-4">Actions Régulières</h3>
          
          {/* Distribution Alimentaire */}
          <div className="mb-6 p-4 bg-black/30 rounded-lg border border-gold/10">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-gold font-semibold">Distribution Alimentaire</h4>
              <span className="text-sm text-gray-400">Mercredi & Vendredi</span>
            </div>
            <div className="space-y-2 text-gray-300 text-sm">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-gold" />
                <span>20h00 - 22h30</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-gold" />
                <span>Minimum 3 personnes requises</span>
              </div>
              <div className="flex items-center gap-2">
                <Car className="h-4 w-4 text-gold" />
                <span>1 conducteur nécessaire</span>
              </div>
            </div>
            <button
              onClick={() => handleParticipate('distribution', 'volunteer')}
              className="mt-4 w-full bg-gold/10 text-gold py-2 rounded-md hover:bg-gold/20 transition-colors"
            >
              Participer
            </button>
          </div>

          {/* Groupes d'Étude */}
          <div className="p-4 bg-black/30 rounded-lg border border-gold/10">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-gold font-semibold">Groupes d'Étude</h4>
              <span className="text-sm text-gray-400">Lundi & Jeudi</span>
            </div>
            <div className="space-y-2 text-gray-300 text-sm">
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-gold" />
                <span>14h00 - 20h00</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-gold" />
                <span>1 responsable minimum par créneau</span>
              </div>
            </div>
            <button
              onClick={() => handleParticipate('study', 'responsible')}
              className="mt-4 w-full bg-gold/10 text-gold py-2 rounded-md hover:bg-gold/20 transition-colors"
            >
              Gérer un créneau
            </button>
          </div>
        </div>

        <div className="bg-black/50 rounded-xl p-6 border border-gold/10">
          <h3 className="text-xl font-bold text-gold mb-4">Événements à venir</h3>
          <div className="space-y-4">
            {events.map((event) => (
              <div
                key={event.id}
                className="p-4 bg-black/30 rounded-lg border border-gold/10"
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-gold font-semibold">{event.title}</h4>
                  <span className="text-sm text-gray-400">{event.date}</span>
                </div>
                <div className="space-y-2 text-gray-300 text-sm">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-gold" />
                    <span>{event.time}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CalendarIcon className="h-4 w-4 text-gold" />
                    <span>{event.location}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}